#!/bin/bash

rm -rvf *.mod *.o

FC="gfortran -fno-range-check -c"


$FC shr_kind_mod.F
$FC shr_const_mod.F90
$FC infnan.F90
$FC physconst.F90
